Write a program to calculate square of a given number N.

Input : first line of input contains no of test cases T.
then each line contains number N.

Ouput : each line contains sqare of input N.

Examle :
Input : 
2
3
5
Output :
9
25

Exlaination: 
first line 2 (2 test cases)
then each input 3 and 5 on seperate line.
their output 
3^2 = 9
5^2 = 25